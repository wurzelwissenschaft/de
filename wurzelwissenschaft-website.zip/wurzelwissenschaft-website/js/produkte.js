/*
  ============================================================
  WURZELWISSENSCHAFT – PRODUKTLISTE
  ============================================================
  So fügst du ein Produkt hinzu: einen Block { ... } kopieren,
  darunter einfügen (Komma dazwischen!) und anpassen.

    name      Produktname
    kurz      1 Satz: was ist das?
    infos     Liste mit Eckdaten
    geeignet  Für welche Pflanzen / Situationen
    tipp      Pflege-Tipp von Wurzelwissenschaft
    bild      eigenes Bild (z. B. "bilder/mein-foto.jpg")
    link      Amazon-Partnerlink
  ============================================================
*/

const PRODUKTE = {

  licht: [
    {
      name: "SANSI T10 Stehende Pflanzenlampe",
      kurz: "Standlampe mit Vollspektrum-Licht für große Pflanzen und dunkle Ecken im Wohnzimmer.",
      infos: ["Vollspektrum", "55 Watt", "Stehlampe – kein Regal oder Haken nötig", "Mit Fernbedienung"],
      geeignet: "Monstera, Ficus, Strelitzie und andere große Pflanzen, die im Winter zu wenig Licht bekommen.",
      tipp: "Im Winter 10–12 Stunden am Tag leuchten lassen und den Kopf von oben auf die Pflanze richten.",
      bild: "bilder/lampe-steh.svg",
      link: "https://link.amazon/B09x9j1CM"
    },
    {
      name: "LED-Pflanzenlampe mit 243 LEDs",
      kurz: "Stehende Wachstumslampe mit mehreren Köpfen und drei Lichtmodi.",
      infos: ["243 LEDs", "3 Modi: Rot, Blau, Vollspektrum", "Stehend für drinnen"],
      geeignet: "Pflanzengruppen, Anzucht und Kräuter auf der Fensterbank.",
      tipp: "Für Zimmerpflanzen den Vollspektrum-Modus nutzen – das reine Rot-Blau-Licht ist eher für Anzucht gedacht.",
      bild: "bilder/lampe-led.svg",
      link: "https://link.amazon/B063tW7Vw"
    }
  ],

  erde: [
    {
      name: "Westland Zimmerpflanzenerde, 8 l",
      kurz: "Fertige Blumenerde mit Tongranulat – speichert Wasser und verteilt Nährstoffe gleichmäßig.",
      infos: ["8 Liter", "Mit Tongranulat", "Für ideale Wasser- und Nährstoffverteilung"],
      geeignet: "Die meisten grünen Zimmerpflanzen: Efeutute, Grünlilie, Einblatt, Zamioculcas.",
      tipp: "Für Pflanzen, die Staunässe hassen, 20–30 % Perlite oder mineralisches Substrat untermischen.",
      bild: "bilder/erde-zimmer.svg",
      link: "https://link.amazon/B0i6dtjh7"
    },
    {
      name: "Floragard Green Jungle Mix, 6 l",
      kurz: "Mineralisches Pflanzsubstrat aus Bims, Zeolith und Lava für Grünpflanzen.",
      infos: ["6 Liter", "Bims, Zeolith und Lava", "Mineralisch, sehr luftig und durchlässig"],
      geeignet: "Monstera, Philodendron, Alocasia und alle, die schnell Wurzelfäule bekommen.",
      tipp: "Mineralisches Substrat trocknet schneller ab – Finger-Test machen und lieber regelmäßig, aber weniger gießen.",
      bild: "bilder/erde-mineral.svg",
      link: "https://link.amazon/B0fd37O3R"
    }
  ],

  moos: [
    {
      name: "Sphagnum-Moosziegel Chile, 100 g",
      kurz: "Gepresstes, langfaseriges Premium-Torfmoos – ergibt aufgequollen etwa 5 Liter.",
      infos: ["100 g Moosziegel", "Ergibt ca. 5 l", "Langfaserig, aus Chile"],
      geeignet: "Moosstäbe für Monstera, Ableger bewurzeln, Orchideen und als Feuchtigkeitsspeicher im Substrat.",
      tipp: "Den Ziegel 15–20 Minuten in lauwarmem Wasser einweichen, dann leicht ausdrücken – fertig.",
      bild: "bilder/moos.svg",
      link: "https://link.amazon/B0e5CLso4"
    }
  ]

};
