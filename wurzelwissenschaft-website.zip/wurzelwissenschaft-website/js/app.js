// Füllt jede <div class="produkte" data-kategorie="..."> mit den Produkten aus produkte.js
(function () {
  if (typeof PRODUKTE === "undefined") return;
  const esc = (s) => String(s || "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  document.querySelectorAll(".produkte[data-kategorie]").forEach((ziel) => {
    const liste = PRODUKTE[ziel.dataset.kategorie] || [];
    ziel.innerHTML = liste.map((p) => `
      <article class="produkt">
        <img src="${esc(p.bild)}" alt="${esc(p.name)}" loading="lazy">
        <div class="inhalt">
          <h3>${esc(p.name)}</h3>
          <p class="kurz">${esc(p.kurz)}</p>
          ${p.infos && p.infos.length ? `<ul class="infos">${p.infos.map((i) => `<li>${esc(i)}</li>`).join("")}</ul>` : ""}
          ${p.geeignet ? `<p class="geeignet"><strong>Geeignet für:</strong> ${esc(p.geeignet)}</p>` : ""}
          ${p.tipp ? `<p class="tipp"><strong>🌱 Wurzelwissenschaft-Tipp:</strong> ${esc(p.tipp)}</p>` : ""}
          ${p.link
            ? `<a class="button" href="${esc(p.link)}" target="_blank" rel="sponsored nofollow noopener">Preis auf Amazon ansehen*</a>`
            : `<span class="button inaktiv">Link folgt</span>`}
        </div>
      </article>`).join("");
  });
})();
